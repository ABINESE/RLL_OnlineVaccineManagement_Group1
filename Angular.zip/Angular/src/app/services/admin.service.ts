import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { apiUrls } from '../../enviroment/apiUrls';
import { environment } from '../../enviroment/environment';
import { localStorageSession } from '../shared/localStorage';
const _baseUrl = environment.BEServer.DevEnviroment;
const _apiUrl = apiUrls.Admin;

// const _authToken = localStorage.getItem('Admin-Token');

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  constructor(
    private _httpClient: HttpClient,
    private _localStorage: localStorageSession
  ) {}

  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${this._localStorage.getItem('Common-Token')}`,
  });

  // 'Content-Type', 'text/plain'
  addVacinnationDetail(_data: any) {
    return this._httpClient.post(
      _baseUrl + _apiUrl.addVacinnationDetail,
      _data,
      {
        headers: this.headers,
      }
    );
  }

  updateVacinnationDetail(_data: any) {
    return this._httpClient.put(
      _baseUrl + _apiUrl.updateVacinnationDetail,
      _data,
      {
        headers: this.headers,
      }
    );
  }

  getAllVacinnationDetail() {
    return this._httpClient.get(_baseUrl + _apiUrl.getAllVacinnationDetail, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this._localStorage.getItem('Common-Token')}`,
      }),
    });
  }

  deleteVacinnationDetail(_data: any) {
    return this._httpClient.delete(
      _baseUrl + _apiUrl.deleteVacinnationDetail + '?Id=' + _data,
      {
        headers: this.headers,
      }
    );
  }

  addUserDetail(_data: any) {
    return this._httpClient.post(_baseUrl + _apiUrl.addUserDetail, _data, {
      headers: this.headers,
    });
  }

  updateUserDetail(_data: any) {
    return this._httpClient.put(_baseUrl + _apiUrl.updateUserDetail, _data, {
      headers: this.headers,
    });
  }

  getAllUserDetail() {
    return this._httpClient.get(_baseUrl + _apiUrl.getAllUserDetail, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this._localStorage.getItem('Common-Token')}`,
      }),
    });
  }

  deleteUserDetail(_data: any) {
    return this._httpClient.delete(
      _baseUrl + _apiUrl.deleteUserDetail + '?Id=' + _data,
      {
        headers: this.headers,
      }
    );
  }

  getUserByUsername(_data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.getUserByUsername + '?Username=' + _data,
      {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this._localStorage.getItem('Common-Token')}`,
        }),
      }
    );
  }

  getAllVaccinationSlots() {
    return this._httpClient.get(_baseUrl + _apiUrl.getAllVaccinationSlots, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this._localStorage.getItem('Common-Token')}`,
      }),
    });
  }
}
