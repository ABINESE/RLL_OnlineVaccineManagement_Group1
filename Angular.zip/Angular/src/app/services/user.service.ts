import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { apiUrls } from '../../enviroment/apiUrls';
import { environment } from '../../enviroment/environment';
import { localStorageSession } from '../shared/localStorage';
const _baseUrl = environment.BEServer.DevEnviroment;
const _apiUrl = apiUrls.User;

// const _authToken = localStorage.getItem('Admin-Token');

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(
    private _httpClient: HttpClient,
    private _localStorage: localStorageSession
  ) {}

  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    Authorization: `Bearer ${this._localStorage.getItem('Common-Token')}`,
  });

  addVaccinationSlot(data: any) {
    return this._httpClient.post(_baseUrl + _apiUrl.addVaccinationSlot, data, {
      headers: this.headers,
    });
  }

  updateVaccinationSlot(_data: any) {
    return this._httpClient.put(_baseUrl + _apiUrl.updateVaccinationSlot, _data, {
      headers: this.headers,
    });
  }

  getAllVaccinationSlots(data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.getAllVaccinationSlots + '?id=' + data,
      {
        headers: this.headers,
      }
    );
  }

  // getAllComments() {
  //   return this._httpClient.get(_baseUrl + _apiUrl.getAllComments + '?id=1', {
  //     headers: this.headers,
  //   });
  // }

  deleteVaccinationSlot(_data: any) {
    return this._httpClient.delete(
      _baseUrl + _apiUrl.deleteVaccinationSlot + '?id=' + _data,
      {
        headers: this.headers,
      }
    );
  }

  

  getMySlotList(data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.getMySlotList+ '?UserID=' + data, //+ _data,
      {
        headers: this.headers,
      }
    );
  }

  getSlotByCity(data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.getSlotByCity + '?City=' + data,
      {
        headers: this.headers,
      }
    );
  }

  getSlotTimeByDate(data: any) {
    return this._httpClient.get(
      _baseUrl + _apiUrl.getSlotTimeByDate + '?Date=' + data,
      {
        headers: this.headers,
      }
    );
  }
  
}
