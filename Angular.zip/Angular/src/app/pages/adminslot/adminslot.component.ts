import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { localStorageSession } from '../../shared/localStorage';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-addtour',
  templateUrl: './adminslot.component.html',
  styleUrl: './adminslot.component.css',
})
export class AdminSlotComponent {
  UserBookingTour: any[] = [];
  List: any[] = [];
  UserID = 0;
  ExperienceID = 0;
  ID = 0;
  IsEdit = false;
  IsReadOnly = false;
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  constructor(
    private router: Router,
    private adminService: AdminService,
    private _localStorage: localStorageSession,
    private _snackBar: MatSnackBar,
    private route: ActivatedRoute
  ) {
    this.UserID = Number(this._localStorage.getItem('Admin-Id'));
  }

  ngOnInit(): void {
    this.getAllVacinnationDetail();
  }

  getAllVacinnationDetail() {
    this.adminService.getAllVacinnationDetail().subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.List = result;
      },
      error: (error: any) => {
        console.log('Error : ', error);
      },
    });
  }

  handleSubmit() {
    if (this.IsEdit) {
      this.handleEditsSlot();
    } else {
      this.handleAddSlot();
    }
  }

  handleAddSlot() {
    let Value = false;
    $('#cityHelp').hide();
    $('#slotHelp').hide();

    if ($('#city').val() === '') {
      $('#cityHelp').show();
      Value = true;
    }

    if (Number($('#slot').val()) <= 0) {
      $('#slotHelp').show();
      Value = true;
    }

    if (Value) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }

    let data = {
      userID: this.UserID,
      city: $('#city').val(),
      slot: Number($('#slot').val()),
      isActive: true,
    };
    this.adminService.addVacinnationDetail(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Add Vaccination Slot Successfully');
        this.getAllVacinnationDetail();
        $('#city').val('');
        $('#slot').val('');
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something Went wrong');
      },
    });
  }

  handleEditsSlot() {
    let Value = false;
    $('#cityHelp').hide();
    $('#slotHelp').hide();

    if ($('#city').val() === '') {
      $('#cityHelp').show();
      Value = true;
    }

    if (Number($('#slot').val()) <= 0) {
      $('#slotHelp').show();
      Value = true;
    }

    if (Value) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }

    let data = {
      text: $('#comment').val(),

      id: this.ID,
      userID: this.UserID,
      city: $('#city').val(),
      slot: Number($('#slot').val()),
    };
    this.adminService.updateVacinnationDetail(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Update Vaccination Slot Successfully');
        this.IsEdit = false;
        this.IsReadOnly = false;
        this.getAllVacinnationDetail();
        $('#city').val('');
        $('#slot').val('');
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something Went wrong');
      },
    });
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  handleEditComment(data: any) {
    this.IsEdit = true;
    this.IsReadOnly = true;
    this.ID = data.id;
    $('#city').val(data.city);
    $('#slot').val(data.slot);
  }

  handleClear() {
    this.IsEdit = false;
    this.IsReadOnly = false;
    this.ID = 0;
    $('#city').val('');
    $('#slot').val('');
  }

  handleDeleteComment(Id: Number) {
    this.adminService.deleteVacinnationDetail(Id).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Delete Vaccination Slot Successfully');
        this.getAllVacinnationDetail();
        this.IsEdit = false;
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something Went wrong');
      },
    });
  }
}
