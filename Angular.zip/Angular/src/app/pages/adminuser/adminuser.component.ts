import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import $ from 'jquery';
import { NgxSpinnerService } from 'ngx-spinner';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { UserService } from '../../services/user.service';
import { localStorageSession } from '../../shared/localStorage';

@Component({
  selector: 'app-edittour',
  templateUrl: './adminuser.component.html',
  styleUrl: './adminuser.component.css',
})
export class AdminUserComponent {
  ID = 0;
  UserID = 0;
  IsEdit = false;
  ExperienceID: Number = 0;
  locationImageUrl: string = '';
  List: any[] = [];
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  IsReadOnly = false;
  constructor(
    private route: ActivatedRoute,
    private adminService: AdminService,
    private spinner: NgxSpinnerService,
    private _snackBar: MatSnackBar,
    private _localStorage: localStorageSession
  ) {
    this.UserID = Number(this._localStorage.getItem('Admin-Id'));
  }

  ngOnInit() {
    this.handleGetAllUserDetail();
  }

  handleGetAllUserDetail() {
    this.adminService.getAllUserDetail().subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.List = result;
      },
      error: (error: any) => {
        console.log('Error : ', error);
      },
    });
  }

  handleValidation() {
    $('#locationNameHelp').hide();
    $('#locationImageUrlHelp').hide();
    $('#confirmPasswordHelp').hide();
    let value = true;
    console.log('locationName : ', $('#locationName').val());

    if ($('#locationName').val() === '') {
      $('#locationNameHelp').show();
      value = false;
    }

    console.log('locationImageUrl : ', $('#locationImageUrl').val());
    if ($('#locationImageUrl').val() === '') {
      $('#locationImageUrlHelp').show();
      value = false;
    }

    console.log('costOfTravel : ', $('#costOfTravel').val());
    if ($('#costOfTravel').val() === '') {
      $('#costOfTravelHelp').show();
      value = false;
    }

    return value;
  }

  handleSubmit() {
    if (this.IsEdit) {
      this.handleEditsUser();
    } else {
      this.handleAddUser();
    }
  }

  handleAddUser() {
    let Value = false;
    $('#usernameHelp').hide();
    $('#passwordHelp').hide();

    if ($('#username').val() === '') {
      $('#usernameHelp').show();
      Value = true;
    }

    if ($('#password').val() === '') {
      $('#passwordHelp').show();
      Value = true;
    }

    if (Value) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }

    let data = {
      email: $('#username').val(),
      password: $('#password').val(),
      role: 'USER',
    };
    this.adminService.addUserDetail(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Add User Detail Successfully');
        this.handleGetAllUserDetail();
        $('#username').val('');
        $('#password').val('');
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something Went wrong');
      },
    });
  }

  handleEditsUser() {
    let Value = false;
    $('#usernameHelp').hide();
    $('#passwordHelp').hide();

    if ($('#username').val() === '') {
      $('#usernameHelp').show();
      Value = true;
    }

    if ($('#password').val() === '') {
      $('#passwordHelp').show();
      Value = true;
    }

    if (Value) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }

    let data = {
      userId: this.UserID,
      email: $('#username').val(),
      password: $('#password').val(),
    };
    this.adminService.updateUserDetail(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Update User Detail Successfully');
        this.IsEdit = false;
        this.IsReadOnly = false;
        this.handleGetAllUserDetail();
        $('#username').val('');
        $('#password').val('');
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something Went wrong');
      },
    });
  }

  handleClear() {
    this.IsEdit = false;
    this.IsReadOnly = false;
    this.ID = 0;
    $('#city').val('');
  }

  handleEditUser(data: any) {
    this.IsEdit = true;
    this.IsReadOnly = true;
    this.ID = data.id;
    $('#username').val(data.email);
  }

  handleDeleteUser(Id: Number) {
    this.adminService.deleteUserDetail(Id).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Delete User Successfully');
        this.handleGetAllUserDetail();
      },
      error: (error: any) => {
        console.log('Error : ', error);
        this.openSnackBar('Something Went wrong');
      },
    });
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, 'close', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }
}
