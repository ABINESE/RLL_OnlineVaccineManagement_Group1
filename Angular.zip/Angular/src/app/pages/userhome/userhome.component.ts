import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import { UserService } from '../../services/user.service';
import { localStorageSession } from '../../shared/localStorage';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrl: './userhome.component.css',
})
export class UserhomeComponent {
  List: any[] = [];
  CityList: any[] = [];
  userID = 0;
  slotId = 0;
  IsReadOnly = true;
  cityName = '';

  Slot1 = true;
  Slot2 = true;
  Slot3 = true;
  Slot4 = true;
  Slot5 = true;
  Slot6 = true;
  Slot7 = true;
  Slot8 = true;
  Slot9 = true;
  Slot10 = true;

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';

  constructor(
    public dialog: MatDialog,
    private _snackBar: MatSnackBar,
    public userService: UserService,
    private adminService: AdminService,
    private _localStorage: localStorageSession
  ) {
    this.userID = this._localStorage.getItem('User-Id');
  }

  ngOnInit(): void {
    this.getAllVacinnationDetail();
  }

  getAllVacinnationDetail() {
    let UserID = Number(this._localStorage.getItem('User-Id'));
    this.adminService.getAllVacinnationDetail().subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.List = result;
        this.CityList = result;
      },
      error: (error: any) => {
        console.log('Error : ', error);
      },
    });
  }

  handleClear() {
    $('#fullname').val('');
    $('#date').val('');
    $('#time').val('');
    $('#city').val('');
    this.IsReadOnly = true;
  }

  handleBookSlot(data: any) {
    if (data.slot <= 0) {
      this.IsReadOnly = true;
      this.openSnackBar('Slot Not Available');
      return;
    }
    this.IsReadOnly = false;
    this.slotId = data.id;
    this.cityName = data.city;
    $('#city').val(data.city);
    // debugger;
  }

  async handleSelectedDate(event: any) {
    console.log('date : ', event.target.value);
    this.Slot1 = false;
    this.Slot2 = false;
    this.Slot3 = false;
    this.Slot4 = false;
    this.Slot5 = false;
    this.Slot6 = false;
    this.Slot7 = false;
    this.Slot8 = false;
    this.Slot9 = false;
    this.Slot10 = false;
    await this.handleGetSlotTimeByDate(event.target.value);
  }

  handleGetSlotTimeByDate(data: any) {
    this.userService.getSlotTimeByDate(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        // debugger;
        if (result.length !== 0) {
          this.Slot1 = result.some(
            (item: any) => item.time === '9:00 AM - 10:00 AM'
          );

          this.Slot2 = result.some(
            (item: any) => item.time === '10:00 AM - 11:00 AM'
          );

          this.Slot3 = result.some(
            (item: any) => item.time === '11:00 AM - 12:00 AM'
          );

          this.Slot4 = result.some(
            (item: any) => item.time === '12:00 AM - 1:00 PM'
          );

          this.Slot5 = result.some(
            (item: any) => item.time === '1:00 PM - 2:00 PM'
          );

          this.Slot6 = result.some(
            (item: any) => item.time === '2:00 PM - 3:00 PM'
          );

          this.Slot7 = result.some(
            (item: any) => item.time === '3:00 PM - 4:00 PM'
          );

          this.Slot8 = result.some(
            (item: any) => item.time === '4:00 PM - 5:00 PM'
          );

          this.Slot9 = result.some(
            (item: any) => item.time === '5:00 PM - 6:00 PM'
          );

          this.Slot10 = result.some(
            (item: any) => item.time === '6:00 PM - 7:00 PM'
          );
        }
      },
      error: (error) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleSubmit() {
    if (this.handlevalidation()) {
      this.openSnackBar('Please Enter Required Field');
      return;
    }
    let data = {
      userID: this.userID,
      slotId: this.slotId,
      username: $('#fullname').val(),
      slotDate: $('#date').val(),
      time: $('#time').val(),
      city: $('#city').val(),
    };

    this.userService.addVaccinationSlot(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Add vaccination Successfully');
        this.getAllVacinnationDetail();
        this.handleClear();
      },
      error: (error) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handlevalidation() {
    $('#fullnameHelp').hide();
    $('#dateHelp').hide();
    $('#timeHelp').hide();
    $('#cityHelp').hide();

    let Value = false;

    if ($('#fullname').val() === '') {
      $('#fullnameHelp').show();
      Value = true;
    }

    if ($('#date').val() === '') {
      $('#dateHelp').show();
      Value = true;
    }

    if ($('#time').val() === '') {
      $('#timeHelp').show();
      Value = true;
    }

    if ($('#city').val() === '') {
      $('#cityHelp').show();
      Value = true;
    }

    return Value;
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  handleSearchCitySlot() {
    let city = $('#city').val();
    if (city === '') {
      this.getAllVacinnationDetail();
      return;
    }

    this.userService.getSlotByCity(city).subscribe((result: any) => {
      console.log('Result : ', result);
      this.List = result;
    });
  }

  handleSearchClear() {
    $('#city').val('');
    this.getAllVacinnationDetail();
  }
}
