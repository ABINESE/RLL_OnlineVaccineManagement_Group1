import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { localStorageSession } from '../../shared/localStorage';

@Component({
  selector: 'app-userdashboard',
  templateUrl: './userdashboard.component.html',
  styleUrl: './userdashboard.component.css',
})
export class UserdashboardComponent {
  constructor(
    private router: Router,
    private _localStorage: localStorageSession
  ) {}

  ngOnInit(): void {
    if (this._localStorage.getItem('User-Token') === null) {
      this.router.navigate(['']);
    }
  }

  handleNavHome() {
    console.log('Navigate To Home');
    this.router.navigate(['/userdashboard/home']);
  }

  handleNavHistory() {
    console.log('Navigate To history');
    this.router.navigate(['/userdashboard/history']);
  }

  handleNavMyBooking() {
    console.log('Navigate To My Booking');
    this.router.navigate(['/userdashboard/mybooking']);
  }

  handleNavSignOut() {
    console.log('Navigate To SignOut');
    this._localStorage.removeItem('User-Id');
    this._localStorage.removeItem('User-Token');
    this._localStorage.removeItem('User-Email');
    this.router.navigate(['']);
  }
}
