import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { localStorageSession } from '../../shared/localStorage';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { CertificationComponent } from '../certification/certification.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-mybooking',
  templateUrl: './history.component.html',
  styleUrl: './history.component.css',
})
export class HistoryComponent {
  ID = 0;
  List: any[] = [];
  userID = 0;
  slotId = 0;
  IsReadOnly = true;

  Slot1 = true;
  Slot2 = true;
  Slot3 = true;
  Slot4 = true;
  Slot5 = true;
  Slot6 = true;
  Slot7 = true;
  Slot8 = true;
  Slot9 = true;
  Slot10 = true;

  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';

  constructor(
    private router: Router,
    private serviceService: UserService,
    private _localStorage: localStorageSession,
    private _snackBar: MatSnackBar,
    private route: ActivatedRoute,
    public userService: UserService,
    private dialog: MatDialog
  ) {
    this.userID = Number(this._localStorage.getItem('User-Id'));
  }

  ngOnInit(): void {
    this.getMySlotList();
  }

  getMySlotList() {
    this.serviceService.getMySlotList(this.userID).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.List = result;
      },
      error: (error: any) => {
        console.log('Error : ', error);
      },
    });
  }

  async handleSelectedDate(event: any) {
    console.log('date : ', event.target.value);
    this.Slot1 = false;
    this.Slot2 = false;
    this.Slot3 = false;
    this.Slot4 = false;
    this.Slot5 = false;
    this.Slot6 = false;
    this.Slot7 = false;
    this.Slot8 = false;
    this.Slot9 = false;
    this.Slot10 = false;
    await this.handleGetSlotTimeByDate(event.target.value);
  }

  handleGetSlotTimeByDate(data: any) {
    this.userService.getSlotTimeByDate(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        // debugger;
        if (result.length !== 0) {
          this.Slot1 = result.some(
            (item: any) => item.time === '9:00 AM - 10:00 AM'
          );

          this.Slot2 = result.some(
            (item: any) => item.time === '10:00 AM - 11:00 AM'
          );

          this.Slot3 = result.some(
            (item: any) => item.time === '11:00 AM - 12:00 AM'
          );

          this.Slot4 = result.some(
            (item: any) => item.time === '12:00 AM - 1:00 PM'
          );

          this.Slot5 = result.some(
            (item: any) => item.time === '1:00 PM - 2:00 PM'
          );

          this.Slot6 = result.some(
            (item: any) => item.time === '2:00 PM - 3:00 PM'
          );

          this.Slot7 = result.some(
            (item: any) => item.time === '3:00 PM - 4:00 PM'
          );

          this.Slot8 = result.some(
            (item: any) => item.time === '4:00 PM - 5:00 PM'
          );

          this.Slot9 = result.some(
            (item: any) => item.time === '5:00 PM - 6:00 PM'
          );

          this.Slot10 = result.some(
            (item: any) => item.time === '6:00 PM - 7:00 PM'
          );
        }
      },
      error: (error) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleClear() {
    $('#fullname').val('');
    $('#date').val('');
    $('#time').val('');
    $('#city').val('');
    this.IsReadOnly = true;
  }

  async handleEditBookSlot(data: any) {
    this.IsReadOnly = false;
    this.ID = data.id;
    this.slotId = data.slotId;
    $('#city').val(data.city);
    $('#fullname').val(data.username);
    $('#date').val(data.slotDate);
    $('#time').val(data.time);
    await this.handleGetSlotTimeByDate(data.slotDate);
  }

  handleSubmit() {
    if (this.handlevalidation()) {
      return;
    }
    let data = {
      userID: this.userID,
      slotId: this.slotId,
      username: $('#fullname').val(),
      slotDate: $('#date').val(),
      time: $('#time').val(),
      city: $('#city').val(),
      id: this.ID,
    };

    this.userService.updateVaccinationSlot(data).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Update vaccination Successfully');
        this.getMySlotList();
        this.handleClear();
      },
      error: (error) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handlevalidation() {
    $('#fullnameHelp').hide();
    $('#dateHelp').hide();
    $('#timeHelp').hide();
    $('#cityHelp').hide();

    let Value = false;

    if ($('#fullname').val() === '') {
      $('#fullnameHelp').show();
      Value = true;
    }

    if ($('#date').val() === '') {
      $('#dateHelp').show();
      Value = true;
    }

    if ($('#time').val() === '') {
      $('#timeHelp').show();
      Value = true;
    }

    if ($('#city').val() === '') {
      $('#cityHelp').show();
      Value = true;
    }

    return Value;
  }

  handleDeleteBookSlot(id: any) {
    this.userService.deleteVaccinationSlot(id).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Delete vaccination Slot Successfully');
        this.getMySlotList();
        this.handleClear();
      },
      error: (error) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, '', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  handleDownloadPdf(dataObject: any) {
    /*
    {
      id: 0,
      createdDate: null,
      userID: 0,
      slotId: 0,
      username: '',
      slotDate: '',
      time: '',
      city: '',
    }
    */

    const dialogRef = this.dialog.open(CertificationComponent, {
      width: '400px', // specify width if needed
      data: dataObject,
    });

    dialogRef.afterClosed().subscribe((result: any) => {
      console.log('Dialog closed with result:', result);
    });
  }
}
