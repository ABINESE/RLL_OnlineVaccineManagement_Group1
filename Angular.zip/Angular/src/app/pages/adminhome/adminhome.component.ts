import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AdminSlotComponent } from '../adminslot/adminslot.component';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarModule,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrl: './adminhome.component.css',
})
export class AdminhomeComponent {
  placeList: any[] = [];
  cityList: any[] = [];
  userID = 0;
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  constructor(
    public dialog: MatDialog,
    private router: Router,
    public adminService: AdminService,
    private _snackBar: MatSnackBar,
    public userService: UserService
  ) {}

  ngOnInit(): void {
    this.getAllVaccinationSlots();
  }

  getAllVaccinationSlots() {
    this.adminService.getAllVaccinationSlots().subscribe((result: any) => {
      console.log('Result : ', result);
      this.placeList = result;
    });
  }

  handleNevigateTour() {
    this.router.navigate(['/admindashboard/addtour']);
  }

  handleEditTour(id: number) {
    this.router.navigate(['/admindashboard/edittour/' + id]);
  }

  handleRemoveTour(tourId: Number) {
  }

  openSnackBar(message: string) {
    this._snackBar.open(message, 'close', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: 3000,
    });
  }

  handleDeleteBookSlot(id: any) {
    this.userService.deleteVaccinationSlot(id).subscribe({
      next: (result: any) => {
        console.log('Result : ', result);
        this.openSnackBar('Delete vaccination Slot Successfully');
        this.getAllVaccinationSlots();
      },
      error: (error) => {
        console.log('Error : ', error);
        this.openSnackBar('Something went wrong');
      },
    });
  }

  handleSearchUser() {
    let keyword = $('#keyword').val();
    if (keyword === '') {
      this.getAllVaccinationSlots();
      return;
    }

    this.adminService.getUserByUsername(keyword).subscribe((result: any) => {
      console.log('Result : ', result);
      this.placeList = result;
    });
  }

  handleSearchClear() {
    $('#keyword').val('');
    this.getAllVaccinationSlots();
  }
}
