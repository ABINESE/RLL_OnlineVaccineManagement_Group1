export const apiUrls = {
  Authentication: {
    SignIn: 'auth/login',
    SignUp: 'auth/signup',
    findEmail: 'auth/findEmail',
    changepassword: 'auth/changepassword',
  },
  Admin: {
    addVacinnationDetail: 'admin/addVacinnationDetail',
    updateVacinnationDetail: 'admin/updateVacinnationDetail',
    getAllVacinnationDetail: 'admin/getAllVacinnationDetail',
    deleteVacinnationDetail: 'admin/deleteVacinnationDetail',

    addUserDetail: 'admin/addUserDetail',
    updateUserDetail: 'admin/updateUserDetail',
    getAllUserDetail: 'admin/getAllUserDetail',
    deleteUserDetail: 'admin/deleteUserDetail',

    getUserByUsername: 'admin/getUserByUsername',
    getAllVaccinationSlots: 'admin/getAllVaccinationSlots',
  },
  User: {
    addVaccinationSlot: 'user/addVaccinationSlot',
    updateVaccinationSlot: 'user/updateVaccinationSlot',
    getAllVaccinationSlots: 'user/getAllVaccinationSlots',
    deleteVaccinationSlot: 'user/deleteVaccinationSlot',

    getMySlotList: 'user/getMySlotList',
    getSlotByCity: 'user/getSlotByCity',
    getSlotTimeByDate: 'user/getSlotTimeByDate',
  },
};
