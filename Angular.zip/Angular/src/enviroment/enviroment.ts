export const environment = {
    production: false,
  
    BEServer: {
      DevEnviroment: 'https://localhost:7010/api/',
    },
  };
  