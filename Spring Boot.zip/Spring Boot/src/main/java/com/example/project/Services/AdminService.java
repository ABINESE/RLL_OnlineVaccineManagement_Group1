package com.example.project.Services;

import com.example.project.Enums.UserRole;
import com.example.project.Models.SlotDetail;
import com.example.project.Models.User;
import com.example.project.Models.UserVaccinationDetail;
import com.example.project.Repositories.SlotDetailDAO;
import com.example.project.Repositories.UserDAO;
import com.example.project.Repositories.UserVaccinationDetailDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminService {

    @Autowired
    SlotDetailDAO slotDetailDAO;

    @Autowired
    UserDAO userDAO;

    @Autowired
    UserVaccinationDetailDAO userVaccinationDetailDAO;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public String addVacinnationDetail(SlotDetail request) {

        try {

            Optional<SlotDetail> response = slotDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getCity().toLowerCase().equalsIgnoreCase(request.getCity().toLowerCase()) && x.getIsActive())
                    .findFirst();

            if(response.isPresent())
            {
                return "City Already Exist In System";
            }

            slotDetailDAO.save(request);
            return "Added SlotDetail!";

        }catch (Exception ex)
        {
            return ex.getMessage();
        }

    }

    public String updateVacinnationDetail(SlotDetail request){

        try{

            Optional<SlotDetail> response = slotDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==request.getId())
                    .findFirst();

            if(!response.isPresent()) {
                return "Invalid Vaccine Id";
            }

            response.get().setUserID(request.getUserID());
            //response.get().setCity(request.getCity());
            response.get().setSlot(request.getSlot());
            slotDetailDAO.save(response.get());

            return "Update SlotDetail successfully";

        }catch (Exception ex){
            return ex.getMessage();
        }

    }

    public List<SlotDetail> getAllVacinnationDetail(){

        try{
            return slotDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getIsActive())
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

    public String deleteVacinnationDetail(Long Id){

        try{

            Optional<SlotDetail> response = slotDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==Id)
                    .findFirst();

            if(!response.isPresent())
            {
                return "Invalid Vaccine Id";
            }

            response.get().setIsActive(false);
            slotDetailDAO.save(response.get());

            return "Delete SlotDetail Successfully";

        }catch (Exception ex){
            return null;
        }
    }


    // User

    public String addUserDetail(User request) {

        try {

            Optional<User> response = userDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getEmail().toLowerCase().equalsIgnoreCase(request.getEmail().toLowerCase()))
                    .findFirst();

            if(response.isPresent())
            {
                return "UserName Already Exist";
            }

            User user = new User();
            user.setEmail(request.getEmail());
            user.setRole(request.getRole());
            user.setPassword(passwordEncoder.encode(request.getPassword()));
            userDAO.save(user);
            return "Added User Successfully!";

        }catch (Exception ex)
        {
            return ex.getMessage();
        }

    }

    public String updateUserDetail(User request){

        try{

            Optional<User> response = userDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getUserId()==request.getUserId())
                    .findFirst();

            if(!response.isPresent())
            {
                return "Invalid User Id";
            }

            response.get().setPassword(passwordEncoder.encode(request.getPassword()));
            userDAO.save(response.get());

            return "Update User successfully";

        }catch (Exception ex){
            return ex.getMessage();
        }

    }

    public List<User> getAllUserDetail(){

        try{
            return userDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getRole() == UserRole.USER)
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

    public String deleteUserDetail(Long Id){

        try{

            Optional<User> response = userDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getUserId()==Id)
                    .findFirst();

            if(!response.isPresent())
            {
                return "Invalid User Id";
            }

            userDAO.delete(response.get());

            return "Delete User Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    //

    public List<UserVaccinationDetail>  getUservaccinationDetailByUsername(String username){

        try{
            return userVaccinationDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getUsername().toLowerCase().equalsIgnoreCase(username.toLowerCase()))
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

    public List<UserVaccinationDetail> getAllVaccinationSlots(){
        try{
            return userVaccinationDetailDAO
                    .findAll()
                    .stream()
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

}
