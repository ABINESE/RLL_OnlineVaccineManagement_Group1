package com.example.project.Controllers;

import com.example.project.DTO.*;
import com.example.project.Models.SlotDetail;
import com.example.project.Models.UserVaccinationDetail;
import com.example.project.Services.UserService;
import com.example.project.Utils.JWTUtil;
import com.example.project.Utils.RoleConfig;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("api/user")
public class UserController {

    @Autowired
    UserService userService;

    @Autowired
    private JWTUtil jwtUtility;

    @Autowired
    private RoleConfig roleConfig;

    Date currentDate = new Date();

    // Add vaccination Slot

    @PostMapping("/addVaccinationSlot")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity addVaccinationSlot(@RequestBody UserVaccinationDetail request) {
        try {


            String response = userService.addVaccinationSlot(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/addUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/updateVaccinationSlot")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity updateVaccinationSlot(@RequestBody UserVaccinationDetail request) {

        try {
            String response = userService.updateVaccinationSlot(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/updateUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/getAllVaccinationSlots")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getAllVaccinationSlots(@RequestParam Long id) {

        try {
            List<UserVaccinationDetail> response = userService.getAllVaccinationSlots(id);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/deleteVaccinationSlot")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity deleteVaccinationSlot(@RequestParam Long id) {

        try {
            String response = userService.deleteVaccinationSlot(id);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/user/deleteUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    //

    @GetMapping("/getMySlotList")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getMySlotList(@RequestParam Long UserID) {

        try {
            List<UserVaccinationDetail> response = userService.getMySlotList(UserID);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }


    //

    @GetMapping("/getSlotByCity")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getSlotByCity(@RequestParam String City) {

        try {
            List<SlotDetail> response = userService.getSlotByCity(City);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/getSlotTimeByDate")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getSlotTimeByDate(@RequestParam String Date) {

        try {
            List<UserVaccinationDetail> response = userService.getSlotTimeByDate(Date);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

}
