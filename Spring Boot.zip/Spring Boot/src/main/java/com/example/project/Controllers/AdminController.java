package com.example.project.Controllers;

import com.example.project.DTO.*;
import com.example.project.Models.SlotDetail;
import com.example.project.Models.User;
import com.example.project.Models.UserVaccinationDetail;
import com.example.project.Services.AdminService;
import com.example.project.Utils.RoleConfig;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("api/admin")
public class AdminController {

    @Autowired
    AdminService adminService;

    @Autowired
    private RoleConfig roleConfig;

    Date currentDate = new Date();

    //Vaccine

    @PostMapping("/addVacinnationDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity addVacinnationDetail(@RequestBody SlotDetail request) {
        try{

            String response = adminService.addVacinnationDetail(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);

        }catch (Exception ex){
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/acct/payments");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/updateVacinnationDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity updateVacinnationDetail(@RequestBody SlotDetail request){
        try{
            String response = adminService.updateVacinnationDetail(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity(_response, HttpStatus.OK);

        }catch (Exception ex){
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/updatetourlocation");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/getAllVacinnationDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getAllVacinnationDetail(){
        try{
            List<SlotDetail> response = adminService.getAllVacinnationDetail();
            return new ResponseEntity(response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

    @DeleteMapping("/deleteVacinnationDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity deleteVacinnationDetail(@RequestParam Long Id){

        try{
            String response = adminService.deleteVacinnationDetail(Id);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity(_response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

    //User

    @PostMapping("/addUserDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity addUserDetail(@RequestBody User request) {
        try{

            String response = adminService.addUserDetail(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);

        }catch (Exception ex){
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/acct/payments");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/updateUserDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity updateUserDetail(@RequestBody User request){
        try{
            String response = adminService.updateUserDetail(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity(_response, HttpStatus.OK);

        }catch (Exception ex){
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/updatetourlocation");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/getAllUserDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getAllUserDetail(){
        try{
            List<User> response = adminService.getAllUserDetail();
            return new ResponseEntity(response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

    @DeleteMapping("/deleteUserDetail")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity deleteUserDetail(@RequestParam Long Id){

        try{
            String response = adminService.deleteUserDetail(Id);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity(_response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }


    // Search User
    @GetMapping("/getUserByUsername")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getUserByUsername(@RequestParam String Username){
        try{
            List<UserVaccinationDetail> response = adminService.getUservaccinationDetailByUsername(Username);
            return new ResponseEntity(response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

    @GetMapping("/getAllVaccinationSlots")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getAllVaccinationSlots() {

        try {
            List<UserVaccinationDetail> response = adminService.getAllVaccinationSlots();
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

}
