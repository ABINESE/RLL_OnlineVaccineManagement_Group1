package com.example.project.Repositories;

import com.example.project.Models.UserVaccinationDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserVaccinationDetailDAO extends JpaRepository<UserVaccinationDetail, Long> {
}
