package com.example.project.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpdateUserVaccinationDetailDTO {
    private Long id;

    private Long userID;

    private Long slotId;

    private Long previousSlotId;

    private String username;

    private String slotDate;

    private String time;

    private String city;
}
