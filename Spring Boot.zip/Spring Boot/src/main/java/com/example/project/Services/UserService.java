package com.example.project.Services;

import com.example.project.DTO.*;
import com.example.project.Models.SlotDetail;
import com.example.project.Models.UserVaccinationDetail;
import com.example.project.Repositories.SlotDetailDAO;
import com.example.project.Repositories.UserVaccinationDetailDAO;
import com.example.project.Repositories.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    UserDAO userDAO;

    @Autowired
    UserVaccinationDetailDAO userVaccinationDetailDAO;

    @Autowired
    SlotDetailDAO slotDetailDAO;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    // User Vaccination Slot

    public String addVaccinationSlot(UserVaccinationDetail request){
        try{

            Optional<SlotDetail> response = slotDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()== request.getSlotId())
                    .findFirst();

            if(!response.isPresent()){
                return "Slot Detail Not Found";
            }

            // Update Slot
            if(response.get().getSlot()<=0) {
                return "Slot Not Available";
            }else{
                response.get().setSlot(response.get().getSlot()-1);
                slotDetailDAO.save(response.get());
            }

            userVaccinationDetailDAO.save(request);
            return "Add Vaccination Detail Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public String updateVaccinationSlot(UserVaccinationDetail request){
        try{

            Optional<UserVaccinationDetail> response = userVaccinationDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()== request.getId())
                    .findFirst();

            if(!response.isPresent()){
                return "Vaccination Detail Not Found";
            }

            /*
            private Date createdDate;
            private Long userID;
            private Long slotId;
            private String username;
            private String slotDate;
            private String time;
            private String city;
            */

            response.get().setCreatedDate(new Date());
            response.get().setUserID(request.getUserID());
            response.get().setSlotId(request.getSlotId());
            response.get().setUsername(request.getUsername());
            response.get().setSlotDate(request.getSlotDate());
            response.get().setTime(request.getTime());
            response.get().setCity(request.getCity());
            userVaccinationDetailDAO.save(response.get());
            return "Update Vaccination Detail Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public List<UserVaccinationDetail> getAllVaccinationSlots(Long Id){
        try{
            return userVaccinationDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getUserID()==Id)
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

    public String deleteVaccinationSlot(Long Id){
        try{

            Optional<UserVaccinationDetail> response = userVaccinationDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==Id)
                    .findFirst();

            if(!response.isPresent()){
                return "UserVaccinationDetail Not Present";
            }

            //Update Slot detail

            Optional<SlotDetail> slotResponse = slotDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()== response.get().getSlotId())
                    .findFirst();

            if(!slotResponse.isPresent()){
                return "Slot Detail Not Found";
            }

            // Update Slot
            slotResponse.get().setSlot(slotResponse.get().getSlot()+1);
            slotDetailDAO.save(slotResponse.get());

            userVaccinationDetailDAO.delete(response.get());
            return "Delete UserVaccinationDetail Successfully";

        }
        catch (Exception ex){
            return null;
        }

    }

    //
    public List<UserVaccinationDetail>  getMySlotList(Long UserID){

        try{
            return userVaccinationDetailDAO.findAll().stream().filter(x->x.getUserID()==UserID).toList();
        }catch (Exception ex){
            return null;
        }
    }

    //
    public List<SlotDetail>  getSlotByCity(String City){

        try{
            return slotDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getCity().toLowerCase().equalsIgnoreCase(City.toLowerCase()) && x.getIsActive())
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }



    public List<UserVaccinationDetail>  getSlotTimeByDate(String Date){

        try{
            return userVaccinationDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getSlotDate().equalsIgnoreCase(Date))
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

}
