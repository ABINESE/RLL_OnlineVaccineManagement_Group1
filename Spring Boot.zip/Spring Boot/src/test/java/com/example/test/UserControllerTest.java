package com.example.test;

import com.example.project.Controllers.UserController;
import com.example.project.Models.UserVaccinationDetail;
import com.example.project.Services.UserService;
import com.example.project.Utils.JWTUtil;
import com.example.project.Utils.RoleConfig;
import org.apache.coyote.Response;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.util.Date;

import static org.mockito.Mockito.doThrow;

@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

    @InjectMocks
    UserController userController;

    @Mock
    UserService userService;

    @Mock
    private JWTUtil jwtUtility;

    @Mock
    private RoleConfig roleConfig;

    Date currentDate = new Date();

    @Test
    void addVaccinationSlotTest() {
        ResponseEntity result = userController.addVaccinationSlot(ArgumentMatchers.any());
    }

    @Test
    void addVaccinationSlotExcepTest() {
        doThrow(new NullPointerException()).when(userService).addVaccinationSlot(ArgumentMatchers.any());
        ResponseEntity result = userController.addVaccinationSlot(ArgumentMatchers.any());
    }

    @Test
    void updateVaccinationSlotTest() {
        ResponseEntity result = userController.updateVaccinationSlot(ArgumentMatchers.any());
    }

    @Test
    void updateVaccinationSlotExcepTest() {
        doThrow(new NullPointerException()).when(userService).updateVaccinationSlot(ArgumentMatchers.any());
        ResponseEntity result = userController.updateVaccinationSlot(ArgumentMatchers.any());
    }

    @Test
    void getAllVaccinationSlotsTest() {
        ResponseEntity result = userController.getAllVaccinationSlots(ArgumentMatchers.any());
    }

    @Test
    void getAllVaccinationSlotsExcepTest() {
        doThrow(new NullPointerException()).when(userService).getAllVaccinationSlots(ArgumentMatchers.any());
        ResponseEntity result = userController.getAllVaccinationSlots(ArgumentMatchers.any());
    }

    @Test
    void deleteVaccinationSlotTest() {
        ResponseEntity result = userController.deleteVaccinationSlot(ArgumentMatchers.any());
    }

    @Test
    void deleteVaccinationSlotExcepTest() {
        doThrow(new NullPointerException()).when(userService).deleteVaccinationSlot(ArgumentMatchers.any());
        ResponseEntity result = userController.deleteVaccinationSlot(ArgumentMatchers.any());
    }

    @Test
    void getMySlotListTest() {
        ResponseEntity result = userController.getMySlotList(ArgumentMatchers.any());
    }

    @Test
    void getMySlotListExcepTest() {
        doThrow(new NullPointerException()).when(userService).getMySlotList(ArgumentMatchers.any());
        ResponseEntity result = userController.getMySlotList(ArgumentMatchers.any());
    }


    @Test
    void getSlotByCityTest() {
        ResponseEntity result = userController.getSlotByCity(ArgumentMatchers.any());
    }

    @Test
    void getSlotByCityExcepTest() {
        doThrow(new NullPointerException()).when(userService).getSlotByCity(ArgumentMatchers.any());
        ResponseEntity result = userController.getSlotByCity(ArgumentMatchers.any());
    }

    @Test
    void getSlotTimeByDateTest() {
        ResponseEntity result = userController.getSlotTimeByDate(ArgumentMatchers.any());
    }

    @Test
    void getSlotTimeByDateExcepTest() {
        doThrow(new NullPointerException()).when(userService).getSlotTimeByDate(ArgumentMatchers.any());
        ResponseEntity result = userController.getSlotTimeByDate(ArgumentMatchers.any());
    }






}
