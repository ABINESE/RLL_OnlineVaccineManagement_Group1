package com.example.test;


import com.example.project.Controllers.AdminController;
import com.example.project.Models.SlotDetail;
import com.example.project.Services.AdminService;
import com.example.project.Utils.RoleConfig;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.matches;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AdminControllerTest {

    @InjectMocks
    AdminController adminController;

    @Mock
    AdminService adminService;

    @Mock
    private RoleConfig roleConfig;

    @Test
    void addVacinnationDetailTest() {
        SlotDetail request = mock(SlotDetail.class);
        when(adminService.addVacinnationDetail(request)).thenReturn(ArgumentMatchers.anyString());
        ResponseEntity result = adminController.addVacinnationDetail(request);
    }

    @Test
    void addVacinnationDetailExcpTest() {
        SlotDetail request = mock(SlotDetail.class);
        Exception e = new NullPointerException();
        doThrow(e).when(adminService).addVacinnationDetail(request);
        ResponseEntity result = adminController.addVacinnationDetail(request);

    }

    @Test
    void updateVacinnationDetailTest() {
        SlotDetail request = mock(SlotDetail.class);
        when(adminService.updateVacinnationDetail(request)).thenReturn(ArgumentMatchers.anyString());
        ResponseEntity result = adminController.updateVacinnationDetail(request);
    }

    @Test
    void updateVacinnationDetailExcpTest() {
        SlotDetail request = mock(SlotDetail.class);
        Exception e = new NullPointerException();
        doThrow(e).when(adminService).updateVacinnationDetail(request);
        ResponseEntity result = adminController.updateVacinnationDetail(request);

    }

    @Test
    void getAllVacinnationDetailTest() {
        ResponseEntity result = adminController.getAllVacinnationDetail();
    }

    @Test
    void deleteVacinnationDetailTest() {
        ResponseEntity result = adminController.deleteVacinnationDetail(ArgumentMatchers.anyLong());
    }

    @Test
    void addUserDetailTest() {
        ResponseEntity result = adminController.addUserDetail(ArgumentMatchers.any());
    }

    @Test
    void addUserDetailExcepTest() {
        doThrow(new NullPointerException()).when(adminService).addUserDetail(ArgumentMatchers.any());
        ResponseEntity result = adminController.addUserDetail(ArgumentMatchers.any());
    }

    @Test
    void updateUserDetailTest() {
        ResponseEntity result = adminController.updateUserDetail(ArgumentMatchers.any());
    }

    @Test
    void updateUserDetailExcepTest() {
        doThrow(new NullPointerException()).when(adminService).updateUserDetail(ArgumentMatchers.any());
        ResponseEntity result = adminController.updateUserDetail(ArgumentMatchers.any());
    }

    @Test
    void getAllUserDetailTest() {
        ResponseEntity result = adminController.getAllUserDetail();
    }

    @Test
    void deleteUserDetailTest() {
        ResponseEntity result = adminController.deleteUserDetail(ArgumentMatchers.anyLong());
    }


    @Test
    void getUserByUsernameTest() {
        ResponseEntity result = adminController.getUserByUsername(ArgumentMatchers.anyString());
    }

    @Test
    void getAllVaccinationSlotsTest(){
        ResponseEntity result = adminController.getAllVaccinationSlots();
    }

}
